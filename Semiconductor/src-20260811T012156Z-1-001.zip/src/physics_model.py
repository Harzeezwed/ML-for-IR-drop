"""
physics_model.py
----------------
Physics-informed multi-scale weighted least squares model for static IR drop
prediction on VLSI power delivery networks.

Model overview
--------------
IR drop at each pixel is predicted by a linear combination of 31 physics-derived
features extracted from three layout maps: current density J(x,y), PDN density
rho(x,y), and effective distance to the nearest supply pad d(x,y). The model is
fit by bounded-variable least squares (BVLS) with a non-negativity constraint on
all coefficients, which enforces the physically correct direction of influence.

Feature groups
--------------
  1. Isotropic Gaussian blurs of J at 9 spatial scales (sigma = 1 to 100 px)
  2. Six PDN interaction terms: J*rho, rho*d, rho/d, d/rho, 1/(d*rho), 1/d^2
  3. Seven anisotropic Gaussian blurs of J (vertical sigma > horizontal sigma)
  4. Two difference-of-Gaussians features clipped to zero (local current elevation)
  5. Two anisotropic-blur x PDN interaction terms (vertical current in sparse PDN)

Training
--------
Real-circuit maps are weighted 10x relative to synthetic maps. A global scale
factor s* is computed after fitting to correct systematic underprediction bias.
Pixel subsampling on synthetic maps reduces RAM without meaningful accuracy loss.

Performance (10 hidden real-circuit test cases)
----------------------------------------------
  MAE  : 0.227 mV (mean across 10 hidden cases)
  F1   : 0.704    (hotspot threshold = 90th percentile of ground-truth IR drop)

Public interface
----------------
  run_all(use_scale, subsample, f1_display)    -- full training and evaluation
  predict_new(current, pdn, eff_dist, params)  -- predict a single new map
  compute_metrics(pred, target)                -- evaluate predictions
"""

import os
import glob
import time
import warnings

import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.optimize import lsq_linear
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec

warnings.filterwarnings("ignore")

try:
    from IPython.display import display, Image as IPImage
    _JUPYTER = True
except ImportError:
    _JUPYTER = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

REAL_DIR   = "benchmarks/real-circuit-data"
FAKE_DIR   = "benchmarks/fake-circuit-data"
HIDDEN_DIR = "benchmarks/hidden-real-circuit-data"
OUT_DIR    = "predictions_final"

BLUR_BANK      = np.array([1, 2, 4, 8, 16, 32, 50, 75, 100], dtype=np.float64)
EPS_PDN        = 0.1
EPS_DIST       = 1e-6
REAL_WEIGHT    = 10.0
HOTSPOT_FRAC   = 0.90
HOTSPOT_PCT    = 90
PDN_BLUR_SIGMA = 20.0

# F1 display mode for diagnostic figures.
# "comp"  -- threshold at 0.90 * max(GT) per testcase
# "unet"  -- threshold at 90th percentile of GT values  (reported as F1)
# "pct"   -- separate 90th percentile thresholds for GT and prediction
# "all"   -- show both the unet overlay and the competition row
F1_DISPLAY = "unet"

# Anisotropic Gaussian blur pairs (sigma_row, sigma_col).
# sigma_row controls vertical spread; sigma_col controls horizontal spread.
# Vertical-dominant pairs capture the stripe structure observed in ground-truth
# IR drop maps, which arises from the vertical orientation of PDN metal layers.
ANISO_BANK = [
    (50,  10),
    (10,  50),
    (50,  25),
    (25,  50),
    (100, 10),
    (75,  15),
    (30,   5),
]

# Difference-of-Gaussians pairs (sigma_wide, sigma_narrow).
# Each feature = max(0, J*G_wide - J*G_narrow) and detects locations where
# local current demand exceeds the surrounding neighbourhood average.
DOG_PAIRS = [
    (50,  8),
    (50, 20),
]

# Indices into ANISO_BANK for the anisotropic x PDN interaction features.
ANISO_PDN_IDX = [0, 2]

# ---------------------------------------------------------------------------
# Internal feature name lists (used to label coefficients in printed output)
# ---------------------------------------------------------------------------

_INTER_KEYS = ["x_cp", "x_pr", "x_p_over_r", "x_r_over_p", "x_inv_rp", "x_inv_r2"]
_INTER_LBLS = ["c*p", "p*r", "p/r", "r/p", "1/(r*p)", "1/r^2"]
_ANISO_KEYS = [f"x_aniso_{sr}v{sc}" for sr, sc in ANISO_BANK]
_ANISO_LBLS = [f"J_aniso({sr}v,{sc}h)" for sr, sc in ANISO_BANK]
_DOG_KEYS   = [f"x_dog_{sw}m{sn}" for sw, sn in DOG_PAIRS]
_DOG_LBLS   = [f"DoG({sw}-{sn}px)" for sw, sn in DOG_PAIRS]
_APDN_KEYS  = [f"x_aniso_pdn_{ANISO_BANK[i][0]}v{ANISO_BANK[i][1]}" for i in ANISO_PDN_IDX]
_APDN_LBLS  = [f"J_aniso({ANISO_BANK[i][0]}v,{ANISO_BANK[i][1]}h)*pdn" for i in ANISO_PDN_IDX]


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_csv(path):
    """Load a comma-delimited CSV file and return a float64 numpy array."""
    return np.loadtxt(path, delimiter=",", dtype=np.float64)


def load_real_testcase(folder):
    """
    Load the four CSV maps for one real-circuit testcase.

    Parameters
    ----------
    folder : str
        Path to the testcase directory containing current_map.csv,
        pdn_density.csv, eff_dist_map.csv, and ir_drop_map.csv.

    Returns
    -------
    tuple of four 2-D numpy arrays : (current, pdn, eff_dist, ir_drop)
    """
    return (
        load_csv(os.path.join(folder, "current_map.csv")),
        load_csv(os.path.join(folder, "pdn_density.csv")),
        load_csv(os.path.join(folder, "eff_dist_map.csv")),
        load_csv(os.path.join(folder, "ir_drop_map.csv")),
    )


def load_fake_sample(prefix):
    """
    Load the four CSV maps for one synthetic (BeGAN-generated) sample.

    Parameters
    ----------
    prefix : str
        Path prefix shared by the four files, e.g. 'benchmarks/fake-circuit-data/sample_001'.

    Returns
    -------
    tuple of four 2-D numpy arrays : (current, pdn, eff_dist, ir_drop)
    """
    return (
        load_csv(f"{prefix}_current.csv"),
        load_csv(f"{prefix}_pdn_density.csv"),
        load_csv(f"{prefix}_eff_dist.csv"),
        load_csv(f"{prefix}_ir_drop.csv"),
    )


def build_case(name, current, pdn, eff_dist, ir_drop):
    """
    Pre-compute all 31 features for one training or inference sample and
    return them as a dictionary.

    Parameters
    ----------
    name     : str   -- identifier used in printed output
    current  : ndarray (H, W) -- cell current demand map  [A or normalised A]
    pdn      : ndarray (H, W) -- PDN density map  [0, 1]
    eff_dist : ndarray (H, W) -- effective distance to nearest supply pad  [um]
    ir_drop  : ndarray (H, W) -- ground-truth IR drop  [V]  (set to zeros for inference)

    Returns
    -------
    dict containing flattened feature arrays and the target vector.
    """
    H, W = ir_drop.shape
    N    = H * W

    blurred = np.zeros((len(BLUR_BANK), N), dtype=np.float64)
    for i, s in enumerate(BLUR_BANK):
        blurred[i] = gaussian_filter(current, sigma=float(s)).flatten()

    aniso_blurred = np.zeros((len(ANISO_BANK), N), dtype=np.float64)
    for i, (sr, sc) in enumerate(ANISO_BANK):
        aniso_blurred[i] = gaussian_filter(current, sigma=(float(sr), float(sc))).flatten()

    pdn_blur = gaussian_filter(pdn, sigma=float(PDN_BLUR_SIGMA))

    c   = current.flatten().astype(np.float64)
    p   = pdn.flatten().astype(np.float64)
    pb  = pdn_blur.flatten().astype(np.float64)
    r   = eff_dist.flatten().astype(np.float64)

    p_s  = np.maximum(p,  EPS_PDN)
    pb_s = np.maximum(pb, EPS_PDN)
    r_s  = np.maximum(r,  EPS_DIST)

    case = dict(
        name=name, shape=(H, W),
        current=current, pdn=pdn, eff_dist=eff_dist, ir_drop=ir_drop,
        x_raw      = c,
        x_dist     = r,
        x_pdn_r    = 1.0 / p_s,
        x_j_dist   = c * r,
        x_cp       = c   * pb,
        x_pr       = pb  * r,
        x_p_over_r = pb  / r_s,
        x_r_over_p = r   / pb_s,
        x_inv_rp   = 1.0 / (r_s * pb_s),
        x_inv_r2   = 1.0 / (r_s ** 2),
        blurred    = blurred,
        y          = ir_drop.flatten().astype(np.float64),
    )

    for i, key in enumerate(_ANISO_KEYS):
        case[key] = aniso_blurred[i]

    for i, (sw, sn) in enumerate(DOG_PAIRS):
        wide   = gaussian_filter(current, sigma=float(sw)).flatten()
        narrow = gaussian_filter(current, sigma=float(sn)).flatten()
        case[_DOG_KEYS[i]] = np.maximum(wide - narrow, 0.0)

    for j, idx in enumerate(ANISO_PDN_IDX):
        case[_APDN_KEYS[j]] = aniso_blurred[idx] * pb

    return case


def load_all_data(verbose=True):
    """
    Load and pre-compute features for all training maps.

    Returns
    -------
    real_cases : list of case dicts for the 10 real-circuit training maps
    fake_cases : list of case dicts for the 100 synthetic training maps
    """
    t0 = time.time()
    real_cases, fake_cases = [], []

    folders = sorted([
        os.path.join(REAL_DIR, d)
        for d in os.listdir(REAL_DIR)
        if os.path.isdir(os.path.join(REAL_DIR, d))
    ])

    if verbose:
        print(f"Loading {len(folders)} real maps ...")
    for folder in folders:
        name = os.path.basename(folder)
        try:
            case = build_case(name, *load_real_testcase(folder))
            real_cases.append(case)
            if verbose:
                ir = case["ir_drop"]
                print(f"  {name:12s}  {case['shape']}  "
                      f"IR=[{ir.min()*1e3:.2f}, {ir.max()*1e3:.2f}] mV")
        except Exception as exc:
            print(f"  ERROR {name}: {exc}")

    prefixes = sorted(set(
        f.replace("_current.csv", "")
        for f in glob.glob(os.path.join(FAKE_DIR, "*_current.csv"))
    ))
    if verbose:
        print(f"\nLoading {len(prefixes)} synthetic maps ...")
    for i, prefix in enumerate(prefixes):
        try:
            fake_cases.append(build_case(f"syn_{i:03d}", *load_fake_sample(prefix)))
        except Exception:
            pass

    if verbose:
        n_blur = (len(real_cases) + len(fake_cases)) * len(BLUR_BANK)
        print(f"Precomputed in {time.time()-t0:.1f}s  ({n_blur} gaussian_filter calls)")

    return real_cases, fake_cases


# ---------------------------------------------------------------------------
# Model fitting
# ---------------------------------------------------------------------------

def compute_scales(all_cases):
    """
    Compute per-feature standard deviation for column normalisation.
    The returned array has one entry per column of the design matrix.
    """
    nb = len(BLUR_BANK)
    s  = [1.0]
    s.append(max(float(np.concatenate([c["x_raw"] for c in all_cases]).std()), 1e-10))
    for i in range(nb):
        b = np.concatenate([c["blurred"][i] for c in all_cases])
        s.append(max(float(b.std()), 1e-10))
    for key in ["x_dist", "x_pdn_r", "x_j_dist"]:
        s.append(max(float(np.concatenate([c[key] for c in all_cases]).std()), 1e-10))
    for key in _INTER_KEYS:
        s.append(max(float(np.concatenate([c[key] for c in all_cases]).std()), 1e-10))
    for key in _ANISO_KEYS:
        s.append(max(float(np.concatenate([c[key] for c in all_cases]).std()), 1e-10))
    for key in _DOG_KEYS:
        s.append(max(float(np.concatenate([c[key] for c in all_cases]).std()), 1e-10))
    for key in _APDN_KEYS:
        s.append(max(float(np.concatenate([c[key] for c in all_cases]).std()), 1e-10))
    return np.array(s)


def build_X(cases, case_weight, scales, subsample=1.0, rng_seed=42):
    """
    Assemble the normalised design matrix from a list of case dicts.

    Parameters
    ----------
    cases       : list of case dicts
    case_weight : scalar weight applied to every row from this set
    scales      : 1-D array from compute_scales
    subsample   : fraction of pixels to sample from each map (default 1.0).
                  Values below 1.0 are only applied when case_weight < REAL_WEIGHT,
                  so real-circuit maps always use all their pixels.
    rng_seed    : integer seed for reproducible subsampling

    Returns
    -------
    X : (N, 31) float64 design matrix
    y : (N,)    float64 target vector
    w : (N,)    float64 sample weights
    """
    nb  = len(BLUR_BANK)
    ni  = len(_INTER_KEYS)
    na  = len(_ANISO_KEYS)
    nd  = len(_DOG_KEYS)
    rng = np.random.default_rng(rng_seed)
    Xp, yp, wp = [], [], []

    for c in cases:
        n = len(c["x_raw"])
        if subsample < 1.0 and case_weight < REAL_WEIGHT:
            idx = rng.choice(n, max(int(n * subsample), 1000), replace=False)
            idx = np.sort(idx)
        else:
            idx = slice(None)

        def _col(arr):
            return arr[idx].astype(np.float64)

        cols = [np.ones(len(c["x_raw"][idx])), _col(c["x_raw"] / scales[1])]
        for i in range(nb):
            cols.append(_col(c["blurred"][i] / scales[2 + i]))
        cols.append(_col(c["x_dist"]   / scales[2 + nb]))
        cols.append(_col(c["x_pdn_r"]  / scales[3 + nb]))
        cols.append(_col(c["x_j_dist"] / scales[4 + nb]))
        for k, key in enumerate(_INTER_KEYS):
            cols.append(_col(c[key] / scales[5 + nb + k]))
        for k, key in enumerate(_ANISO_KEYS):
            cols.append(_col(c[key] / scales[5 + nb + ni + k]))
        for k, key in enumerate(_DOG_KEYS):
            cols.append(_col(c[key] / scales[5 + nb + ni + na + k]))
        for k, key in enumerate(_APDN_KEYS):
            cols.append(_col(c[key] / scales[5 + nb + ni + na + nd + k]))

        Xp.append(np.column_stack(cols))
        yp.append(c["y"][idx].astype(np.float64))
        wp.append(np.full(len(c["x_raw"][idx]), case_weight, dtype=np.float64))

    return np.vstack(Xp), np.concatenate(yp), np.concatenate(wp)


def fit_model(real_cases, fake_cases, verbose=True, subsample=1.0):
    """
    Fit the weighted least squares model with non-negativity constraints.

    All 31 coefficients are constrained to be >= 0 (BVLS solver). This
    enforces the physical requirement that IR drop can only increase with
    higher current demand, lower PDN density, or greater distance from pads.

    Parameters
    ----------
    real_cases  : list of case dicts for real-circuit training maps
    fake_cases  : list of case dicts for synthetic training maps
    verbose     : print design matrix size and coefficient table
    subsample   : pixel fraction for synthetic maps (default 1.0)
                  Use 0.1 or 0.2 on machines with less than 12 GB of RAM.

    Returns
    -------
    params : dict with key "coeffs" (1-D array of 31 unnormalised coefficients)
    scales : 1-D array used for normalisation (needed for predict_new)
    """
    scales = compute_scales(real_cases + fake_cases)
    Xr, yr, wr = build_X(real_cases, REAL_WEIGHT, scales, subsample=1.0)
    Xf, yf, wf = build_X(fake_cases, 1.0,         scales, subsample=subsample)
    X = np.vstack([Xr, Xf]); del Xr, Xf
    y = np.concatenate([yr, yf]); del yr, yf
    w = np.concatenate([wr, wf]); del wr, wf

    if verbose:
        ram_gb  = X.nbytes / 1e9
        sub_str = f"subsample={subsample}" if subsample < 1.0 else "all pixels"
        print(f"  Design matrix: {X.shape[0]:,} rows x {X.shape[1]} cols  "
              f"({ram_gb:.1f} GB, {sub_str})")

    t0 = time.time()
    sw = np.sqrt(w); del w
    n  = X.shape[1]
    cn = lsq_linear(
        X * sw[:, None], y * sw,
        bounds=([0.0] * n, [1e15] * n),
        method="bvls", tol=1e-12, max_iter=100000,
    ).x
    del X, y, sw

    cp = cn / scales

    if verbose:
        lbls = (
            ["bias", "J_raw"]
            + [f"J_blur_{int(s)}px" for s in BLUR_BANK]
            + ["dist", "PDN_r", "J_x_dist"]
            + _INTER_LBLS + _ANISO_LBLS + _DOG_LBLS + _APDN_LBLS
        )
        print(f"  Solved in {time.time()-t0:.1f}s")
        print(f"\n  {'Feature':<28}  {'Coefficient':>14}  Status")
        print(f"  {'-'*56}")
        for lbl, v in zip(lbls, cp):
            status = "ACTIVE" if v > 1e-20 else "zero"
            print(f"  {lbl:<28}  {v:>14.4e}  {status}")

    return {"coeffs": cp}, scales


def fit_global_scale(real_cases, params, verbose=True):
    """
    Compute s* = sum(GT) / sum(pred) across all real-circuit training pixels.

    This single post-fit scalar corrects any systematic underprediction bias
    introduced by the non-negativity constraint. It is applied uniformly to
    all predictions and does not overfit because it has only one degree of
    freedom.

    Parameters
    ----------
    real_cases : list of case dicts
    params     : dict from fit_model containing "coeffs"
    verbose    : print s* and per-case MAE before/after

    Returns
    -------
    s : float
    """
    sum_gt = sum_pred = 0.0
    for c in real_cases:
        sum_gt   += float(c["y"].sum())
        sum_pred += float(_pred_flat(c, params["coeffs"]).sum())

    s = float(np.clip(sum_gt / max(sum_pred, 1e-30), 0.5, 3.0))

    if verbose:
        print(f"\n  Global scale factor  s* = {s:.4f}")
        print(f"  {'Case':<14}  {'MAE_before':>11}  {'MAE_after':>10}  {'delta%':>8}")
        print(f"  {'-'*48}")
        for c in real_cases:
            p0 = _pred_flat(c, params["coeffs"]).reshape(c["shape"])
            m0 = float(np.mean(np.abs(p0     - c["ir_drop"])))
            m1 = float(np.mean(np.abs(p0 * s - c["ir_drop"])))
            print(f"  {c['name']:<14}  {m0*1e3:>10.3f}  {m1*1e3:>10.3f}  "
                  f"{(m0 - m1) / m0 * 100:>+7.1f}%")

    return s


# ---------------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------------

def _pred_flat(case, coeffs):
    """
    Compute flat (H*W,) IR drop prediction for a pre-built case dict.
    All pixel values are clipped to zero so the output is non-negative.
    """
    nb  = len(BLUR_BANK)
    ni  = len(_INTER_KEYS)
    na  = len(_ANISO_KEYS)
    nd  = len(_DOG_KEYS)

    pred = (
        coeffs[0]
        + coeffs[1] * case["x_raw"]
        + case["blurred"].T @ coeffs[2:2 + nb]
        + coeffs[2 + nb] * case["x_dist"]
        + coeffs[3 + nb] * case["x_pdn_r"]
        + coeffs[4 + nb] * case["x_j_dist"]
    )
    for k, key in enumerate(_INTER_KEYS):
        pred = pred + coeffs[5 + nb + k] * case[key]
    for k, key in enumerate(_ANISO_KEYS):
        pred = pred + coeffs[5 + nb + ni + k] * case[key]
    for k, key in enumerate(_DOG_KEYS):
        pred = pred + coeffs[5 + nb + ni + na + k] * case[key]
    for k, key in enumerate(_APDN_KEYS):
        pred = pred + coeffs[5 + nb + ni + na + nd + k] * case[key]

    return np.clip(pred, 0.0, None)


def predict_case(case, params):
    """Return a (H, W) prediction array for a pre-built case dict."""
    return _pred_flat(case, params["coeffs"]).reshape(case["shape"])


def predict_new(current, pdn, eff_dist, params):
    """
    Predict IR drop for a new set of input maps.

    This is the main inference entry point. It accepts raw input arrays,
    computes all features internally, and returns the predicted IR drop map.

    Parameters
    ----------
    current  : ndarray (H, W) -- cell current demand map
    pdn      : ndarray (H, W) -- PDN density map
    eff_dist : ndarray (H, W) -- effective distance to nearest supply pad
    params   : dict returned by fit_model (must contain key "coeffs")

    Returns
    -------
    pred : ndarray (H, W) -- predicted IR drop in the same units as training data
    """
    tmp = build_case("tmp", current, pdn, eff_dist, np.zeros_like(current))
    return predict_case(tmp, params)


# ---------------------------------------------------------------------------
# Evaluation metrics
# ---------------------------------------------------------------------------

def compute_metrics(pred, target):
    """
    Compute MAE and three variants of F1 score for a single predicted map.

    F1 score reported as the primary metric uses the 90th percentile of
    ground-truth IR drop values as the hotspot threshold (F1_unet). Pixels
    above this threshold are considered hotspots. F1 measures how well the
    model identifies these high-severity locations.

    Parameters
    ----------
    pred   : ndarray (H, W) -- predicted IR drop
    target : ndarray (H, W) -- ground-truth IR drop

    Returns
    -------
    dict with keys: mae, f1_unet, prec_unet, rec_unet, thr_unet, tp_u, fp_u, fn_u,
                    f1_comp, prec_comp, rec_comp, thr_comp, tp_c, fp_c, fn_c,
                    f1_pct,  prec_pct,  rec_pct,  thr_pct_gt, thr_pct_pred, tp_p, fp_p, fn_p
    """
    p = pred.flatten().astype(np.float64)
    t = target.flatten().astype(np.float64)
    mae = float(np.mean(np.abs(p - t)))

    def _f1(ph, th):
        tp = int(np.sum((ph == 1) & (th == 1)))
        fp = int(np.sum((ph == 1) & (th == 0)))
        fn = int(np.sum((ph == 0) & (th == 1)))
        pr = tp / (tp + fp + 1e-8)
        rc = tp / (tp + fn + 1e-8)
        return 2 * pr * rc / (pr + rc + 1e-8), float(pr), float(rc), tp, fp, fn

    # Primary F1: threshold at 90th percentile of ground-truth values
    thr_u = float(np.percentile(t, HOTSPOT_PCT))
    f1_u, pr_u, rc_u, tp_u, fp_u, fn_u = _f1(
        (p >= thr_u).astype(int), (t >= thr_u).astype(int)
    )

    # Secondary F1: threshold at 90% of the maximum ground-truth value
    thr_c = HOTSPOT_FRAC * float(t.max())
    f1_c, pr_c, rc_c, tp_c, fp_c, fn_c = _f1(
        (p >= thr_c).astype(int), (t >= thr_c).astype(int)
    )

    # Reference F1: separate 90th percentile thresholds for GT and prediction
    thr_p_gt   = float(np.percentile(t, HOTSPOT_PCT))
    thr_p_pred = float(np.percentile(p, HOTSPOT_PCT))
    f1_p, pr_p, rc_p, tp_p, fp_p, fn_p = _f1(
        (p >= thr_p_pred).astype(int), (t >= thr_p_gt).astype(int)
    )

    return dict(
        mae=mae,
        f1_unet=float(f1_u), prec_unet=float(pr_u), rec_unet=float(rc_u),
        thr_unet=thr_u, tp_u=tp_u, fp_u=fp_u, fn_u=fn_u,
        f1_comp=float(f1_c), prec_comp=float(pr_c), rec_comp=float(rc_c),
        thr_comp=thr_c, tp_c=tp_c, fp_c=fp_c, fn_c=fn_c,
        f1_pct=float(f1_p), prec_pct=float(pr_p), rec_pct=float(rc_p),
        thr_pct_gt=thr_p_gt, thr_pct_pred=thr_p_pred, tp_p=tp_p, fp_p=fp_p, fn_p=fn_p,
    )


# ---------------------------------------------------------------------------
# Diagnostic visualisation
# ---------------------------------------------------------------------------

def _hotspot_rgb(gt_hot, pred_hot, ir_gt, vmin_ir, vmax_ir):
    tp_m = gt_hot & pred_hot
    fp_m = ~gt_hot & pred_hot
    fn_m = gt_hot & ~pred_hot
    bg   = (ir_gt - vmin_ir) / (vmax_ir - vmin_ir + 1e-12) * 0.25
    rgb  = np.stack([bg, bg, bg], -1).astype(np.float32)
    rgb[tp_m] = [0.0, 0.85, 0.0]
    rgb[fp_m] = [1.0, 0.15, 0.15]
    rgb[fn_m] = [1.0, 0.80, 0.0]
    return np.clip(rgb, 0, 1), int(tp_m.sum()), int(fp_m.sum()), int(fn_m.sum())


def visualise(name, current, pdn, eff_dist, ir_gt, ir_pred,
              save_dir=OUT_DIR, f1_display=None):
    """
    Save a diagnostic figure showing input maps, predicted IR drop, error,
    hotspot overlay, scatter plot, and metrics summary.

    The figure is saved to save_dir/<name>.png and displayed inline when
    running inside a Jupyter notebook.

    Parameters
    ----------
    name       : str
    current    : ndarray (H, W)
    pdn        : ndarray (H, W)
    eff_dist   : ndarray (H, W)
    ir_gt      : ndarray (H, W) -- ground-truth IR drop
    ir_pred    : ndarray (H, W) -- predicted IR drop
    save_dir   : output directory (created if it does not exist)
    f1_display : override the global F1_DISPLAY setting for this figure
    """
    os.makedirs(save_dir, exist_ok=True)
    mode = (f1_display if f1_display is not None else F1_DISPLAY).lower()
    if mode not in ("comp", "unet", "pct", "all"):
        raise ValueError(f"f1_display must be comp/unet/pct/all, got '{mode}'")

    m = compute_metrics(ir_pred, ir_gt)
    err = np.abs(ir_pred - ir_gt)
    vmin_ir = float(ir_gt.min())
    vmax_ir = float(ir_gt.max())
    thr_c    = m["thr_comp"]
    thr_p_gt = m["thr_pct_gt"]
    thr_p_pred = m["thr_pct_pred"]

    if mode in ("unet", "all"):
        thr_show = m["thr_unet"]
        mode_label = "unet"
        gt_hot_show   = ir_gt   >= thr_show
        pred_hot_show = ir_pred >= thr_show
    elif mode == "comp":
        thr_show = thr_c
        mode_label = "comp"
        gt_hot_show   = ir_gt   >= thr_show
        pred_hot_show = ir_pred >= thr_show
    else:
        thr_show = thr_p_gt
        mode_label = "pct"
        gt_hot_show   = ir_gt   >= thr_p_gt
        pred_hot_show = ir_pred >= thr_p_pred

    rgb_show, tp_show, fp_show, fn_show = _hotspot_rgb(
        gt_hot_show, pred_hot_show, ir_gt, vmin_ir, vmax_ir
    )
    gt_hot_c   = ir_gt   >= thr_c
    pred_hot_c = ir_pred >= thr_c
    rgb_c, tp_c, fp_c, fn_c = _hotspot_rgb(
        gt_hot_c, pred_hot_c, ir_gt, vmin_ir, vmax_ir
    )

    hs_leg = [
        mpatches.Patch(color=[0, 0.85, 0],   label="TP"),
        mpatches.Patch(color=[1, 0.15, 0.15], label="FP"),
        mpatches.Patch(color=[1, 0.8,  0],   label="FN"),
    ]

    f1_labels = {
        "comp": f"[F1_comp={m['f1_comp']:.4f}]  F1={m['f1_unet']:.4f}  F1_pct={m['f1_pct']:.4f}",
        "unet": f"F1_comp={m['f1_comp']:.4f}  [F1={m['f1_unet']:.4f}]  F1_pct={m['f1_pct']:.4f}",
        "pct":  f"F1_comp={m['f1_comp']:.4f}  F1={m['f1_unet']:.4f}  [F1_pct={m['f1_pct']:.4f}]",
        "all":  f"F1_comp={m['f1_comp']:.4f}  F1={m['f1_unet']:.4f}  F1_pct={m['f1_pct']:.4f}  (overlay=unet)",
    }[mode]

    fig = plt.figure(figsize=(28, 18))
    fig.patch.set_facecolor("white")
    fig.suptitle(
        f"{name}  ({ir_gt.shape[0]}x{ir_gt.shape[1]})\n"
        f"MAE={m['mae']*1e3:.4f} mV    {f1_labels}",
        fontsize=11, fontweight="bold", y=0.99,
    )
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.42, wspace=0.32)

    def imax(ax, data, title, cmap, vn=None, vx=None, unit="mV"):
        kw = dict(vmin=vn, vmax=vx) if vn is not None else {}
        im = ax.imshow(data, cmap=cmap, interpolation="nearest", **kw)
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04).set_label(unit, fontsize=8)
        ax.set_title(title, fontsize=9, fontweight="bold", pad=5)
        ax.axis("off")

    j_log = np.log1p(current.astype(np.float64))
    j_log = (j_log - j_log.min()) / (np.ptp(j_log) + 1e-10)
    pdn_n = (pdn.astype(np.float64) - pdn.min()) / (np.ptp(pdn) + 1e-10)
    d_n   = (eff_dist.astype(np.float64) - eff_dist.min()) / (np.ptp(eff_dist) + 1e-10)

    imax(fig.add_subplot(gs[0, 0]), j_log,       "Current Map\n(log-norm)", "hot", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 1]), pdn_n,        "PDN Density\n(norm)",    "Blues_r", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 2]), d_n,          "Eff. Distance\n(norm)",  "viridis", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 3]), ir_gt * 1e3,  "Ground Truth IR Drop",   "jet",
         vmin_ir * 1e3, vmax_ir * 1e3)
    imax(fig.add_subplot(gs[1, 0]), ir_pred * 1e3, "Predicted IR Drop",     "jet",
         vmin_ir * 1e3, vmax_ir * 1e3)
    imax(fig.add_subplot(gs[1, 1]), err * 1e3,
         f"Absolute Error\n(MAE={m['mae']*1e3:.4f} mV)", "hot")

    _mname = {"comp": "competition", "unet": "unet [90th pct]", "pct": "sep pct thrs"}[mode_label]
    _f1s   = {"comp": m["f1_comp"],  "unet": m["f1_unet"],      "pct": m["f1_pct"]}[mode_label]
    _prs   = {"comp": m["prec_comp"],"unet": m["prec_unet"],     "pct": m["prec_pct"]}[mode_label]
    _rcs   = {"comp": m["rec_comp"], "unet": m["rec_unet"],      "pct": m["rec_pct"]}[mode_label]

    ax = fig.add_subplot(gs[1, 2])
    ax.imshow(gt_hot_show.astype(np.float32), cmap="Reds", interpolation="nearest", vmin=0, vmax=1)
    ax.set_title(f"GT Hotspots [{_mname}]\nthr={thr_show*1e3:.3f} mV  n={int(gt_hot_show.sum()):,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")

    ax = fig.add_subplot(gs[1, 3])
    ax.imshow(rgb_show, interpolation="nearest")
    ax.set_title(f"Pred Hotspots [{_mname}]\nF1={_f1s:.4f}  Prec={_prs:.3f}  Rec={_rcs:.3f}\n"
                 f"TP={tp_show:,}  FP={fp_show:,}  FN={fn_show:,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")
    ax.legend(handles=hs_leg, loc="lower center", ncol=3, fontsize=8,
              frameon=True, bbox_to_anchor=(0.5, -0.06))

    ax = fig.add_subplot(gs[2, 0])
    ax.axis("off")
    if mode == "all":
        ax.imshow(gt_hot_c.astype(np.float32), cmap="Reds", interpolation="nearest", vmin=0, vmax=1)
        ax.set_title(f"GT Hotspots [competition]\nthr={thr_c*1e3:.3f} mV  n={int(gt_hot_c.sum()):,}",
                     fontsize=9, fontweight="bold", pad=5)

    ax = fig.add_subplot(gs[2, 1])
    ax.axis("off")
    if mode == "all":
        ax.imshow(rgb_c, interpolation="nearest")
        ax.set_title(f"Pred Hotspots [competition]\nF1={m['f1_comp']:.4f}  "
                     f"Prec={m['prec_comp']:.3f}  Rec={m['rec_comp']:.3f}\n"
                     f"TP={tp_c:,}  FP={fp_c:,}  FN={fn_c:,}",
                     fontsize=9, fontweight="bold", pad=5)
        ax.legend(handles=hs_leg, loc="lower center", ncol=3, fontsize=8,
                  frameon=True, bbox_to_anchor=(0.5, -0.06))

    ax = fig.add_subplot(gs[2, 2])
    fg  = ir_gt.flatten()
    fp2 = ir_pred.flatten()
    rng = np.random.default_rng(42)
    idx = rng.choice(len(fg), min(10000, len(fg)), replace=False)
    hot_c = fg[idx] >= thr_c
    hot_p = fg[idx] >= thr_p_gt
    ax.scatter(fg[idx[~hot_c]] * 1e3, fp2[idx[~hot_c]] * 1e3,
               c="steelblue", alpha=0.2, s=4, linewidths=0, label="Normal")
    ax.scatter(fg[idx[hot_p & ~hot_c]] * 1e3, fp2[idx[hot_p & ~hot_c]] * 1e3,
               c="orange", alpha=0.5, s=6, linewidths=0, label="Hotspot (pct)")
    ax.scatter(fg[idx[hot_c]] * 1e3, fp2[idx[hot_c]] * 1e3,
               c="red", alpha=0.7, s=8, linewidths=0, label="Hotspot (comp)")
    ax.axhline(thr_c   * 1e3, color="red",    lw=1.5, ls="--", label="thr_comp")
    ax.axvline(thr_c   * 1e3, color="red",    lw=1.5, ls="--")
    ax.axhline(thr_p_gt * 1e3, color="orange", lw=1.0, ls=":",  label="thr_pct")
    ax.axvline(thr_p_gt * 1e3, color="orange", lw=1.0, ls=":")
    lim = [min(vmin_ir * 1e3, fp2.min() * 1e3), max(vmax_ir * 1e3, fp2.max() * 1e3)]
    ax.plot(lim, lim, "k--", lw=1.5, label="y=x")
    ax.set_xlabel("GT IR Drop (mV)", fontsize=9)
    ax.set_ylabel("Pred (mV)", fontsize=9)
    ax.set_title("Scatter\nred = competition threshold", fontsize=9, fontweight="bold", pad=5)
    ax.legend(fontsize=7, loc="upper left")
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[2, 3])
    ax.axis("off")
    summary = (
        "METRICS SUMMARY\n"
        "-------------------------\n"
        f"MAE = {m['mae']*1e3:.4f} mV\n\n"
        "F1 (primary metric)\n"
        f"  thr={m['thr_unet']*1e3:.4f} mV\n"
        f"  F1 ={m['f1_unet']:.4f}\n"
        f"  Pr ={m['prec_unet']:.4f}  Rc={m['rec_unet']:.4f}\n"
        f"  TP/FP/FN={m['tp_u']:,}/{m['fp_u']:,}/{m['fn_u']:,}\n\n"
        "F1_comp\n"
        f"  thr={thr_c*1e3:.4f} mV\n"
        f"  F1 ={m['f1_comp']:.4f}\n"
        f"  Pr ={m['prec_comp']:.4f}  Rc={m['rec_comp']:.4f}\n"
        f"  TP/FP/FN={m['tp_c']:,}/{m['fp_c']:,}/{m['fn_c']:,}\n\n"
        "F1_pct (reference)\n"
        f"  thr_gt  ={thr_p_gt*1e3:.4f} mV\n"
        f"  thr_pred={thr_p_pred*1e3:.4f} mV\n"
        f"  F1 ={m['f1_pct']:.4f}\n"
        f"  Pr ={m['prec_pct']:.4f}  Rc={m['rec_pct']:.4f}\n"
        f"  TP/FP/FN={m['tp_p']:,}/{m['fp_p']:,}/{m['fn_p']:,}"
    )
    ax.text(0.05, 0.97, summary, transform=ax.transAxes, fontsize=8.5,
            fontfamily="monospace", verticalalignment="top",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#fffde7",
                      edgecolor="#bbb", alpha=0.95))

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    sp = os.path.join(save_dir, f"{name}.png")
    plt.savefig(sp, dpi=120, bbox_inches="tight", facecolor="white")
    if _JUPYTER:
        display(IPImage(filename=sp))
    plt.close(fig)

    print(f"  {name:<16}  MAE={m['mae']*1e3:.3f} mV  "
          f"F1={m['f1_unet']:.4f}  F1_comp={m['f1_comp']:.4f}  F1_pct={m['f1_pct']:.4f}")
    return m


# ---------------------------------------------------------------------------
# Main entry points
# ---------------------------------------------------------------------------

def run_all(use_scale=True, subsample=1.0, f1_display=None):
    """
    Train the physics model on all available data and evaluate on the hidden
    test cases.

    Parameters
    ----------
    use_scale  : bool  -- apply the global scale factor s* to predictions
    subsample  : float -- fraction of synthetic map pixels used during fitting
                          (default 1.0 uses all pixels; try 0.2 on machines
                          with less than 12 GB of RAM)
    f1_display : str or None -- hotspot overlay shown in figures:
                   "unet"  threshold at 90th percentile of GT  (default)
                   "comp"  threshold at 90% of max GT
                   "pct"   separate 90th percentile thresholds
                   "all"   show both unet and competition overlays

    Returns
    -------
    params  : dict with key "coeffs" and "global_scale"
    scales  : 1-D array (needed to call predict_new independently)
    results : dict mapping testcase name to prediction array and metrics
    """
    total_t0 = time.time()
    os.makedirs(OUT_DIR, exist_ok=True)

    print("=" * 55)
    print("  Step 1/3 -- Loading data and precomputing features")
    print("=" * 55)
    real_cases, fake_cases = load_all_data(verbose=True)

    print("\n" + "=" * 55)
    print("  Step 2/3 -- Fitting multi-scale WLS model")
    print("=" * 55)
    params, scales = fit_model(real_cases, fake_cases,
                               verbose=True, subsample=subsample)

    print(f"\n{'-'*55}")
    print("  Fitting global scale factor ...")
    print(f"{'-'*55}")
    global_scale = fit_global_scale(real_cases, params, verbose=True)
    params["global_scale"] = global_scale

    s = global_scale if use_scale else 1.0
    scale_label = f"s*={global_scale:.4f}" if use_scale else "s*=OFF (raw model)"
    print(f"\n  Scale applied: {scale_label}")

    print(f"\n{'-'*65}")
    print(f"  Training set in-sample check  ({scale_label})")
    print(f"{'-'*65}")
    print(f"  {'Case':<14}  {'MAE(mV)':>8}  {'F1':>8}  {'F1_comp':>8}  {'F1_pct':>8}")
    print(f"  {'-'*56}")
    train_dir = os.path.join(OUT_DIR, "training_check")
    tc_maes, tc_f1u, tc_f1c, tc_f1p = [], [], [], []
    for c in real_cases:
        pred = predict_case(c, params) * s
        m    = compute_metrics(pred, c["ir_drop"])
        tc_maes.append(m["mae"])
        tc_f1u.append(m["f1_unet"])
        tc_f1c.append(m["f1_comp"])
        tc_f1p.append(m["f1_pct"])
        print(f"  {c['name']:<14}  {m['mae']*1e3:>8.3f}  "
              f"{m['f1_unet']:>8.4f}  {m['f1_comp']:>8.4f}  {m['f1_pct']:>8.4f}")
        visualise(c["name"] + "_train", c["current"], c["pdn"], c["eff_dist"],
                  c["ir_drop"], pred, save_dir=train_dir, f1_display=f1_display)
    print(f"  {'-'*56}")
    print(f"  {'MEAN':<14}  {np.mean(tc_maes)*1e3:>8.3f}  "
          f"{np.mean(tc_f1u):>8.4f}  {np.mean(tc_f1c):>8.4f}  {np.mean(tc_f1p):>8.4f}")

    print(f"\n{'='*65}")
    print("  Step 3/3 -- Predicting hidden test cases")
    print(f"{'='*65}")
    hidden_folders = sorted([
        os.path.join(HIDDEN_DIR, d)
        for d in os.listdir(HIDDEN_DIR)
        if os.path.isdir(os.path.join(HIDDEN_DIR, d))
    ])
    print(f"  Found {len(hidden_folders)} hidden cases\n")

    results = {}
    for folder in hidden_folders:
        name = os.path.basename(folder)
        try:
            current, pdn, eff_dist, ir_gt = load_real_testcase(folder)
            pred = predict_new(current, pdn, eff_dist, params) * s
            m    = compute_metrics(pred, ir_gt)
            results[name] = {"pred": pred, "gt": ir_gt, "metrics": m}
            np.savetxt(os.path.join(OUT_DIR, f"{name}_pred.csv"),
                       pred, delimiter=",", fmt="%.6e")
            visualise(name, current, pdn, eff_dist, ir_gt, pred,
                      save_dir=OUT_DIR, f1_display=f1_display)
        except Exception as exc:
            print(f"  {name}: {exc}")
            import traceback
            traceback.print_exc()

    if results:
        maes = [r["metrics"]["mae"]      for r in results.values()]
        f1u  = [r["metrics"]["f1_unet"]  for r in results.values()]
        f1c  = [r["metrics"]["f1_comp"]  for r in results.values()]
        f1p  = [r["metrics"]["f1_pct"]   for r in results.values()]
        print(f"\n{'='*65}")
        print(f"  FINAL RESULTS  ({scale_label}  {time.time()-total_t0:.1f}s total)")
        print(f"{'='*65}")
        print(f"  Hidden MAE  (mean): {np.mean(maes)*1e3:.4f} mV")
        print(f"  Hidden F1   (mean): {np.mean(f1u):.4f}  (90th pct threshold)")
        print(f"  Hidden F1_comp    : {np.mean(f1c):.4f}  (0.90 x max threshold)")
        print(f"  Hidden F1_pct     : {np.mean(f1p):.4f}  (reference)")
        print(f"\n  {'Case':<14}  {'MAE(mV)':>8}  {'F1':>8}  {'F1_comp':>8}  {'F1_pct':>8}")
        print(f"  {'-'*56}")
        for n, r in sorted(results.items()):
            print(f"  {n:<14}  {r['metrics']['mae']*1e3:>8.4f}  "
                  f"{r['metrics']['f1_unet']:>8.4f}  "
                  f"{r['metrics']['f1_comp']:>8.4f}  "
                  f"{r['metrics']['f1_pct']:>8.4f}")
        print(f"\n  Figures saved to: {os.path.abspath(OUT_DIR)}/")
        print(f"{'='*65}")

    return params, scales, results

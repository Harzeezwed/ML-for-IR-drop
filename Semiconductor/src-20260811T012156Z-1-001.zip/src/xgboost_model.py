"""
xgboost_model.py
----------------
XGBoost gradient-boosted tree model for static IR drop prediction on VLSI
power delivery networks.

Model overview
--------------
A gradient-boosted tree ensemble (XGBRegressor) is trained to predict per-pixel
IR drop from 26 layout-derived features. The same feature groups developed for
the physics model are used here, allowing direct comparison between the two
approaches. CUDA is used automatically when an NVIDIA GPU is detected.

Feature groups (26 total)
--------------------------
  1. Raw current J(x,y)                                        (1 feature)
  2. Isotropic Gaussian blurs of J at 9 spatial scales         (9 features)
  3. Distance, PDN resistance, two blurred PDN maps, J*dist    (5 features)
  4. Anisotropic Gaussian blurs of J (7 vertical-dominant pairs) (7 features)
  5. Difference-of-Gaussians features clipped to zero          (2 features)
  6. Anisotropic-blur x blurred PDN interaction terms          (2 features)

Training
--------
Real-circuit maps are weighted 10x relative to synthetic maps. Subsampling
inside the XGBRegressor (subsample=0.3) keeps memory manageable by processing
only 30% of training pixels per tree.

Performance (10 hidden real-circuit test cases)
----------------------------------------------
  MAE  : 0.243 mV (mean across 10 hidden cases)
  F1   : 0.619    (hotspot threshold = 90th percentile of ground-truth IR drop)

Public interface
----------------
  run_xgb(load_from, params)               -- train or load, then evaluate
  predict_map(model, current, pdn, eff_dist) -- predict a single new map
  compute_metrics(pred, target)            -- evaluate predictions
"""

import os
import glob
import time
import warnings
import subprocess

import numpy as np
from scipy.ndimage import gaussian_filter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec

warnings.filterwarnings("ignore")

try:
    import xgboost as xgb
    print(f"XGBoost version: {xgb.__version__}")
except ImportError:
    raise ImportError("XGBoost is not installed. Run: pip install xgboost")

try:
    from IPython.display import display, Image as IPImage
    _JUPYTER = True
except ImportError:
    _JUPYTER = False


# ---------------------------------------------------------------------------
# CUDA detection
# ---------------------------------------------------------------------------

def _check_cuda():
    """
    Check whether an NVIDIA GPU is available. If so, XGBoost will use CUDA.
    If not, the device setting in XGB_PARAMS is changed to CPU automatically.
    """
    try:
        result = subprocess.run(["nvidia-smi"], capture_output=True, timeout=5)
        if result.returncode == 0:
            print("  GPU detected -- training will use CUDA")
            return True
    except Exception:
        pass
    print("  No GPU detected -- falling back to CPU")
    XGB_PARAMS["device"] = "cpu"
    return False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

REAL_DIR   = "benchmarks/real-circuit-data"
FAKE_DIR   = "benchmarks/fake-circuit-data"
HIDDEN_DIR = "benchmarks/hidden-real-circuit-data"
OUT_DIR    = "predictions_xgb"
MODEL_PATH = "xgb_model.json"

BLUR_BANK      = np.array([1, 2, 4, 8, 16, 32, 50, 75, 100], dtype=np.float64)
EPS_PDN        = 0.1
REAL_WEIGHT    = 10.0
HOTSPOT_FRAC   = 0.90
HOTSPOT_PCT    = 90
PDN_BLUR_SIGMA = 20.0

ANISO_BANK_XGB = [
    (50,  10),
    (50,  25),
    (100, 10),
    (75,  15),
    (30,   5),
    (10,  50),
    (25,  50),
]

DOG_PAIRS_XGB = [
    (50,  8),
    (50, 20),
]

XGB_PARAMS = dict(
    n_estimators     = 500,
    max_depth        = 4,
    learning_rate    = 0.05,
    subsample        = 0.3,
    colsample_bytree = 0.8,
    min_child_weight = 500,
    reg_lambda       = 2.0,
    reg_alpha        = 0.5,
    objective        = "reg:absoluteerror",
    tree_method      = "hist",
    device           = "cuda",
    n_jobs           = -1,
    random_state     = 42,
    verbosity        = 0,
)

_CUDA_AVAILABLE = _check_cuda()

FEATURE_NAMES = (
    ["J_raw"]
    + [f"J_blur_{int(s)}px" for s in BLUR_BANK]
    + ["dist", "PDN_r", "PDN_blur_10", "PDN_blur_30", "J_x_dist"]
    + [f"J_aniso_{sr}v{sc}h" for sr, sc in ANISO_BANK_XGB]
    + [f"DoG_{sw}m{sn}px" for sw, sn in DOG_PAIRS_XGB]
    + [f"J_aniso_{ANISO_BANK_XGB[i][0]}v{ANISO_BANK_XGB[i][1]}h_x_pdn" for i in [0, 1]]
)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_csv(path):
    """Load a comma-delimited CSV file and return a float64 numpy array."""
    return np.loadtxt(path, delimiter=",", dtype=np.float64)


def load_real_testcase(folder):
    """
    Load the four CSV maps for one real-circuit testcase.

    Parameters
    ----------
    folder : str
        Path to the testcase directory.

    Returns
    -------
    tuple : (current, pdn, eff_dist, ir_drop) as 2-D numpy arrays
    """
    return (
        load_csv(os.path.join(folder, "current_map.csv")),
        load_csv(os.path.join(folder, "pdn_density.csv")),
        load_csv(os.path.join(folder, "eff_dist_map.csv")),
        load_csv(os.path.join(folder, "ir_drop_map.csv")),
    )


def load_fake_sample(prefix):
    """
    Load the four CSV maps for one synthetic training sample.

    Parameters
    ----------
    prefix : str
        Shared path prefix for the four CSV files.

    Returns
    -------
    tuple : (current, pdn, eff_dist, ir_drop) as 2-D numpy arrays
    """
    return (
        load_csv(f"{prefix}_current.csv"),
        load_csv(f"{prefix}_pdn_density.csv"),
        load_csv(f"{prefix}_eff_dist.csv"),
        load_csv(f"{prefix}_ir_drop.csv"),
    )


# ---------------------------------------------------------------------------
# Feature extraction
# ---------------------------------------------------------------------------

def extract_features(current, pdn, eff_dist):
    """
    Compute the 26-feature design matrix for one map.

    Parameters
    ----------
    current  : ndarray (H, W)
    pdn      : ndarray (H, W)
    eff_dist : ndarray (H, W)

    Returns
    -------
    ndarray (H*W, 26) float32
    """
    pdn_b20 = gaussian_filter(pdn, float(PDN_BLUR_SIGMA))

    cols = []
    cols.append(current.flatten())
    for s in BLUR_BANK:
        cols.append(gaussian_filter(current, float(s)).flatten())
    cols.append(eff_dist.flatten())
    cols.append(1.0 / (pdn.flatten() + EPS_PDN))
    cols.append(gaussian_filter(pdn, 10.0).flatten())
    cols.append(gaussian_filter(pdn, 30.0).flatten())
    cols.append((current * eff_dist).flatten())

    aniso_maps = []
    for sr, sc in ANISO_BANK_XGB:
        a = gaussian_filter(current, sigma=(float(sr), float(sc))).flatten()
        cols.append(a)
        aniso_maps.append(a)

    for sw, sn in DOG_PAIRS_XGB:
        wide   = gaussian_filter(current, float(sw)).flatten()
        narrow = gaussian_filter(current, float(sn)).flatten()
        cols.append(np.maximum(wide - narrow, 0.0))

    pb = pdn_b20.flatten()
    for i in [0, 1]:
        cols.append(aniso_maps[i] * pb)

    return np.column_stack(cols).astype(np.float32)


def build_case(name, current, pdn, eff_dist, ir_drop):
    """Pre-compute features for one training sample and return a dict."""
    feats = extract_features(current, pdn, eff_dist)
    return dict(
        name=name, shape=ir_drop.shape,
        current=current, pdn=pdn, eff_dist=eff_dist,
        ir_drop=ir_drop,
        features=feats,
        y=ir_drop.flatten().astype(np.float32),
    )


def load_all_data(verbose=True):
    """
    Load all training maps and pre-compute features.

    Returns
    -------
    real_cases : list of case dicts (10 real-circuit maps)
    fake_cases : list of case dicts (100 synthetic maps)
    """
    t0 = time.time()
    real_cases, fake_cases = [], []

    folders = sorted([
        os.path.join(REAL_DIR, d)
        for d in os.listdir(REAL_DIR)
        if os.path.isdir(os.path.join(REAL_DIR, d))
    ])

    if verbose:
        print(f"Loading {len(folders)} real maps ...")
    for folder in folders:
        name = os.path.basename(folder)
        try:
            c = build_case(name, *load_real_testcase(folder))
            real_cases.append(c)
            if verbose:
                ir = c["ir_drop"]
                print(f"  {name:12s}  {c['shape']}  "
                      f"IR=[{ir.min()*1e3:.2f}, {ir.max()*1e3:.2f}] mV")
        except Exception as exc:
            print(f"  ERROR {name}: {exc}")

    prefixes = sorted(set(
        f.replace("_current.csv", "")
        for f in glob.glob(os.path.join(FAKE_DIR, "*_current.csv"))
    ))
    if verbose:
        print(f"\nLoading {len(prefixes)} synthetic maps ...")
    for i, prefix in enumerate(prefixes):
        try:
            fake_cases.append(build_case(f"syn_{i:03d}", *load_fake_sample(prefix)))
        except Exception:
            pass

    if verbose:
        print(f"Features extracted in {time.time()-t0:.1f}s")
    return real_cases, fake_cases


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def build_training_data(real_cases, fake_cases):
    """
    Concatenate all case feature arrays into one training matrix.

    Real-circuit maps are assigned sample weight REAL_WEIGHT; synthetic maps
    receive weight 1.0.

    Returns
    -------
    X : (N, 26) float32
    y : (N,)    float32
    w : (N,)    float32 sample weights
    """
    X_parts, y_parts, w_parts = [], [], []
    for c in real_cases:
        X_parts.append(c["features"])
        y_parts.append(c["y"])
        w_parts.append(np.full(len(c["y"]), REAL_WEIGHT, dtype=np.float32))
    for c in fake_cases:
        X_parts.append(c["features"])
        y_parts.append(c["y"])
        w_parts.append(np.ones(len(c["y"]), dtype=np.float32))
    return np.vstack(X_parts), np.concatenate(y_parts), np.concatenate(w_parts)


def train_xgb(real_cases, fake_cases, params=XGB_PARAMS, verbose=True):
    """
    Train the XGBoost model and print feature importances.

    Parameters
    ----------
    real_cases : list of case dicts
    fake_cases : list of case dicts
    params     : XGBoost hyperparameter dict
    verbose    : print progress

    Returns
    -------
    model : trained XGBRegressor
    """
    if verbose:
        print("  Building training matrix ...")
    t0 = time.time()
    X, y, w = build_training_data(real_cases, fake_cases)
    if verbose:
        device = params.get("device", "cpu")
        print(f"  X shape: {X.shape}  ({X.nbytes/1e9:.2f} GB)")
        print(f"  y range: [{y.min()*1e3:.3f}, {y.max()*1e3:.3f}] mV")
        print(f"  Training XGBoost ({params['n_estimators']} trees, "
              f"subsample={params['subsample']}, device={device}) ...")

    model = xgb.XGBRegressor(**params)
    model.fit(X, y, sample_weight=w, verbose=100 if verbose else False)

    if verbose:
        print(f"  Trained in {time.time()-t0:.1f}s")
        imp    = model.feature_importances_
        ranked = sorted(zip(FEATURE_NAMES, imp), key=lambda x: -x[1])
        print("\n  Feature importances (gain):")
        for fname, fval in ranked:
            bar = "|" * int(fval * 200)
            print(f"    {fname:<22}  {fval:.4f}  {bar}")

    return model


# ---------------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------------

def predict_map(model, current, pdn, eff_dist):
    """
    Predict IR drop for a single new map.

    Parameters
    ----------
    model    : trained XGBRegressor
    current  : ndarray (H, W)
    pdn      : ndarray (H, W)
    eff_dist : ndarray (H, W)

    Returns
    -------
    pred : ndarray (H, W) -- predicted IR drop (clipped to zero)
    """
    feats = extract_features(current, pdn, eff_dist)
    pred  = model.predict(feats)
    return np.clip(pred, 0.0, None).reshape(current.shape)


# ---------------------------------------------------------------------------
# Evaluation metrics
# ---------------------------------------------------------------------------

def compute_metrics(pred, target):
    """
    Compute MAE and three variants of F1 score for a single predicted map.

    F1 score reported as the primary metric uses the 90th percentile of
    ground-truth IR drop values as the hotspot threshold (f1_unet). Pixels
    above this threshold are considered hotspots.

    Parameters
    ----------
    pred   : ndarray (H, W)
    target : ndarray (H, W)

    Returns
    -------
    dict with keys: mae, f1_unet, prec_unet, rec_unet, thr_unet, tp_u, fp_u, fn_u,
                    f1_comp, prec_comp, rec_comp, thr_comp, tp_c, fp_c, fn_c,
                    f1_pct,  prec_pct,  rec_pct,  thr_pct_gt, thr_pct_pred, tp_p, fp_p, fn_p
    """
    p = pred.flatten().astype(np.float64)
    t = target.flatten().astype(np.float64)
    mae = float(np.mean(np.abs(p - t)))

    def _f1(ph, th):
        tp = int(np.sum((ph == 1) & (th == 1)))
        fp = int(np.sum((ph == 1) & (th == 0)))
        fn = int(np.sum((ph == 0) & (th == 1)))
        pr = tp / (tp + fp + 1e-8)
        rc = tp / (tp + fn + 1e-8)
        return 2 * pr * rc / (pr + rc + 1e-8), float(pr), float(rc), tp, fp, fn

    thr_u = float(np.percentile(t, HOTSPOT_PCT))
    f1_u, pr_u, rc_u, tp_u, fp_u, fn_u = _f1(
        (p >= thr_u).astype(int), (t >= thr_u).astype(int)
    )

    thr_c = HOTSPOT_FRAC * float(t.max())
    f1_c, pr_c, rc_c, tp_c, fp_c, fn_c = _f1(
        (p >= thr_c).astype(int), (t >= thr_c).astype(int)
    )

    thr_p_gt   = float(np.percentile(t, HOTSPOT_PCT))
    thr_p_pred = float(np.percentile(p, HOTSPOT_PCT))
    f1_p, pr_p, rc_p, tp_p, fp_p, fn_p = _f1(
        (p >= thr_p_pred).astype(int), (t >= thr_p_gt).astype(int)
    )

    return dict(
        mae=mae,
        f1_unet=float(f1_u), prec_unet=float(pr_u), rec_unet=float(rc_u),
        thr_unet=thr_u, tp_u=tp_u, fp_u=fp_u, fn_u=fn_u,
        f1_comp=float(f1_c), prec_comp=float(pr_c), rec_comp=float(rc_c),
        thr_comp=thr_c, tp_c=tp_c, fp_c=fp_c, fn_c=fn_c,
        f1_pct=float(f1_p), prec_pct=float(pr_p), rec_pct=float(rc_p),
        thr_pct_gt=thr_p_gt, thr_pct_pred=thr_p_pred,
        tp_p=tp_p, fp_p=fp_p, fn_p=fn_p,
    )


# ---------------------------------------------------------------------------
# Diagnostic visualisation
# ---------------------------------------------------------------------------

def _hotspot_rgb(gt_hot, pred_hot, ir_gt, vmin_ir, vmax_ir):
    tp_m = gt_hot & pred_hot
    fp_m = ~gt_hot & pred_hot
    fn_m = gt_hot & ~pred_hot
    bg   = (ir_gt - vmin_ir) / (vmax_ir - vmin_ir + 1e-12) * 0.25
    rgb  = np.stack([bg, bg, bg], -1).astype(np.float32)
    rgb[tp_m] = [0.0, 0.85, 0.0]
    rgb[fp_m] = [1.0, 0.15, 0.15]
    rgb[fn_m] = [1.0, 0.80, 0.0]
    return np.clip(rgb, 0, 1), int(tp_m.sum()), int(fp_m.sum()), int(fn_m.sum())


def visualise(name, current, pdn, eff_dist, ir_gt, ir_pred, save_dir=OUT_DIR):
    """
    Save a diagnostic figure for one testcase. The figure is displayed inline
    when running inside a Jupyter notebook.

    Parameters
    ----------
    name     : str
    current  : ndarray (H, W)
    pdn      : ndarray (H, W)
    eff_dist : ndarray (H, W)
    ir_gt    : ndarray (H, W)
    ir_pred  : ndarray (H, W)
    save_dir : output directory
    """
    os.makedirs(save_dir, exist_ok=True)
    m = compute_metrics(ir_pred, ir_gt)
    err = np.abs(ir_pred - ir_gt)
    vmin_ir    = float(ir_gt.min())
    vmax_ir    = float(ir_gt.max())
    thr_c      = m["thr_comp"]
    thr_p_gt   = m["thr_pct_gt"]
    thr_p_pred = m["thr_pct_pred"]

    gt_hot_u   = ir_gt   >= m["thr_unet"]
    pred_hot_u = ir_pred >= m["thr_unet"]
    rgb_u, tp_u, fp_u, fn_u = _hotspot_rgb(gt_hot_u, pred_hot_u, ir_gt, vmin_ir, vmax_ir)

    gt_hot_c   = ir_gt   >= thr_c
    pred_hot_c = ir_pred >= thr_c
    rgb_c, tp_c, fp_c, fn_c = _hotspot_rgb(gt_hot_c, pred_hot_c, ir_gt, vmin_ir, vmax_ir)

    hs_leg = [
        mpatches.Patch(color=[0, 0.85, 0],   label="TP"),
        mpatches.Patch(color=[1, 0.15, 0.15], label="FP"),
        mpatches.Patch(color=[1, 0.8,  0],   label="FN"),
    ]

    fig = plt.figure(figsize=(28, 18))
    fig.patch.set_facecolor("white")
    fig.suptitle(
        f"{name}  ({ir_gt.shape[0]}x{ir_gt.shape[1]})\n"
        f"MAE={m['mae']*1e3:.4f} mV  "
        f"F1={m['f1_unet']:.4f} [90th pct={m['thr_unet']*1e3:.3f} mV]  "
        f"F1_pct={m['f1_pct']:.4f} [sep pct thrs]",
        fontsize=11, fontweight="bold", y=0.99,
    )
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.42, wspace=0.32)

    def imax(ax, data, title, cmap, vn=None, vx=None, unit="mV"):
        kw = dict(vmin=vn, vmax=vx) if vn is not None else {}
        im = ax.imshow(data, cmap=cmap, interpolation="nearest", **kw)
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04).set_label(unit, fontsize=8)
        ax.set_title(title, fontsize=9, fontweight="bold", pad=5)
        ax.axis("off")

    j_log = np.log1p(current.astype(np.float64))
    j_log = (j_log - j_log.min()) / (np.ptp(j_log) + 1e-10)
    pdn_n = (pdn.astype(np.float64) - pdn.min()) / (np.ptp(pdn) + 1e-10)
    d_n   = (eff_dist.astype(np.float64) - eff_dist.min()) / (np.ptp(eff_dist) + 1e-10)

    imax(fig.add_subplot(gs[0, 0]), j_log,        "Current Map\n(log-norm)", "hot", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 1]), pdn_n,         "PDN Density\n(norm)",    "Blues_r", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 2]), d_n,           "Eff. Distance\n(norm)",  "viridis", 0, 1, "a.u.")
    imax(fig.add_subplot(gs[0, 3]), ir_gt * 1e3,   "Ground Truth IR Drop",   "jet",
         vmin_ir * 1e3, vmax_ir * 1e3)
    imax(fig.add_subplot(gs[1, 0]), ir_pred * 1e3, "Predicted IR Drop",      "jet",
         vmin_ir * 1e3, vmax_ir * 1e3)
    imax(fig.add_subplot(gs[1, 1]), err * 1e3,
         f"Absolute Error\n(MAE={m['mae']*1e3:.4f} mV)", "hot")

    ax = fig.add_subplot(gs[1, 2])
    ax.imshow(gt_hot_u.astype(np.float32), cmap="Reds", interpolation="nearest", vmin=0, vmax=1)
    ax.set_title(f"GT Hotspots [90th pct]\nthr={m['thr_unet']*1e3:.3f} mV  n={int(gt_hot_u.sum()):,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")

    ax = fig.add_subplot(gs[1, 3])
    ax.imshow(rgb_u, interpolation="nearest")
    ax.set_title(f"Pred Hotspots [90th pct]\nF1={m['f1_unet']:.4f}  "
                 f"Prec={m['prec_unet']:.3f}  Rec={m['rec_unet']:.3f}\n"
                 f"TP={tp_u:,}  FP={fp_u:,}  FN={fn_u:,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")
    ax.legend(handles=hs_leg, loc="lower center", ncol=3, fontsize=8,
              frameon=True, bbox_to_anchor=(0.5, -0.06))

    ax = fig.add_subplot(gs[2, 0])
    ax.imshow(gt_hot_c.astype(np.float32), cmap="Reds", interpolation="nearest", vmin=0, vmax=1)
    ax.set_title(f"GT Hotspots [competition]\nthr={thr_c*1e3:.3f} mV  n={int(gt_hot_c.sum()):,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")

    ax = fig.add_subplot(gs[2, 1])
    ax.imshow(rgb_c, interpolation="nearest")
    ax.set_title(f"Pred Hotspots [competition]\nF1={m['f1_comp']:.4f}  "
                 f"Prec={m['prec_comp']:.3f}  Rec={m['rec_comp']:.3f}\n"
                 f"TP={tp_c:,}  FP={fp_c:,}  FN={fn_c:,}",
                 fontsize=9, fontweight="bold", pad=5)
    ax.axis("off")
    ax.legend(handles=hs_leg, loc="lower center", ncol=3, fontsize=8,
              frameon=True, bbox_to_anchor=(0.5, -0.06))

    ax = fig.add_subplot(gs[2, 2])
    fg  = ir_gt.flatten()
    fp2 = ir_pred.flatten()
    rng = np.random.default_rng(42)
    idx = rng.choice(len(fg), min(10000, len(fg)), replace=False)
    hot_c = fg[idx] >= thr_c
    hot_p = fg[idx] >= thr_p_gt
    ax.scatter(fg[idx[~hot_c]] * 1e3, fp2[idx[~hot_c]] * 1e3,
               c="steelblue", alpha=0.2, s=4, linewidths=0, label="Normal")
    ax.scatter(fg[idx[hot_p & ~hot_c]] * 1e3, fp2[idx[hot_p & ~hot_c]] * 1e3,
               c="orange", alpha=0.5, s=6, linewidths=0, label="Hotspot (pct)")
    ax.scatter(fg[idx[hot_c]] * 1e3, fp2[idx[hot_c]] * 1e3,
               c="red", alpha=0.7, s=8, linewidths=0, label="Hotspot (comp)")
    ax.axhline(thr_c    * 1e3, color="red",    lw=1.5, ls="--", label="thr_comp")
    ax.axvline(thr_c    * 1e3, color="red",    lw=1.5, ls="--")
    ax.axhline(thr_p_gt * 1e3, color="orange", lw=1.0, ls=":",  label="thr_pct")
    ax.axvline(thr_p_gt * 1e3, color="orange", lw=1.0, ls=":")
    lim = [min(vmin_ir * 1e3, fp2.min() * 1e3), max(vmax_ir * 1e3, fp2.max() * 1e3)]
    ax.plot(lim, lim, "k--", lw=1.5, label="y=x")
    ax.set_xlabel("GT IR Drop (mV)", fontsize=9)
    ax.set_ylabel("Pred (mV)", fontsize=9)
    ax.set_title("Scatter\nred = competition threshold", fontsize=9, fontweight="bold", pad=4)
    ax.legend(fontsize=7, loc="upper left")
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[2, 3])
    ax.axis("off")
    summary = (
        "METRICS SUMMARY\n"
        "-------------------------\n"
        f"MAE = {m['mae']*1e3:.4f} mV\n\n"
        "F1 (primary metric)\n"
        f"  thr={m['thr_unet']*1e3:.4f} mV\n"
        f"  F1 ={m['f1_unet']:.4f}\n"
        f"  Pr ={m['prec_unet']:.4f}  Rc={m['rec_unet']:.4f}\n"
        f"  TP/FP/FN={tp_u:,}/{fp_u:,}/{fn_u:,}\n\n"
        "F1_comp\n"
        f"  thr={thr_c*1e3:.4f} mV\n"
        f"  F1 ={m['f1_comp']:.4f}\n"
        f"  Pr ={m['prec_comp']:.4f}  Rc={m['rec_comp']:.4f}\n"
        f"  TP/FP/FN={tp_c:,}/{fp_c:,}/{fn_c:,}\n\n"
        "F1_pct (reference)\n"
        f"  thr_gt  ={thr_p_gt*1e3:.4f} mV\n"
        f"  thr_pred={thr_p_pred*1e3:.4f} mV\n"
        f"  F1 ={m['f1_pct']:.4f}\n"
        f"  Pr ={m['prec_pct']:.4f}  Rc={m['rec_pct']:.4f}\n"
        f"  TP/FP/FN={m['tp_p']:,}/{m['fp_p']:,}/{m['fn_p']:,}"
    )
    ax.text(0.05, 0.97, summary, transform=ax.transAxes, fontsize=8.5,
            fontfamily="monospace", verticalalignment="top",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#fffde7",
                      edgecolor="#bbb", alpha=0.95))

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    sp = os.path.join(save_dir, f"{name}.png")
    plt.savefig(sp, dpi=110, bbox_inches="tight", facecolor="white")
    if _JUPYTER:
        display(IPImage(filename=sp))
    plt.close(fig)

    print(f"  {name:<16}  MAE={m['mae']*1e3:.3f} mV  "
          f"F1={m['f1_unet']:.4f}  F1_comp={m['f1_comp']:.4f}  F1_pct={m['f1_pct']:.4f}")
    return m


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_xgb(load_from=None, params=XGB_PARAMS):
    """
    Train (or load) the XGBoost model and evaluate on the hidden test cases.

    Parameters
    ----------
    load_from : str or None
        Path to a saved model checkpoint (.json) to skip training.
        Pass None to train from scratch.
    params : dict
        XGBoost hyperparameter dict. Defaults to XGB_PARAMS.

    Returns
    -------
    model   : trained XGBRegressor
    results : dict mapping testcase name to prediction array and metrics
    """
    total_t0 = time.time()
    os.makedirs(OUT_DIR, exist_ok=True)

    print("=" * 58)
    print("  Step 1 -- Loading data and extracting features")
    print("=" * 58)
    real_cases, fake_cases = load_all_data(verbose=True)

    if load_from and os.path.exists(load_from):
        print(f"\n  Loading model from {load_from} ...")
        model = xgb.XGBRegressor(**params)
        model.load_model(load_from)
        print("  Loaded.")
    else:
        print(f"\n{'='*58}")
        print("  Step 2 -- Training XGBoost")
        print(f"{'='*58}")
        model = train_xgb(real_cases, fake_cases, params, verbose=True)
        model.save_model(MODEL_PATH)
        print(f"\n  Model saved to {MODEL_PATH}")

    print(f"\n{'-'*65}")
    print("  Training set in-sample check")
    print(f"{'-'*65}")
    print(f"  {'Case':<14}  {'MAE(mV)':>8}  {'F1':>8}  {'F1_comp':>8}  {'F1_pct':>8}")
    print(f"  {'-'*56}")
    train_dir = os.path.join(OUT_DIR, "training_check")
    tc_maes, tc_f1u, tc_f1c, tc_f1p = [], [], [], []
    for c in real_cases:
        pred = predict_map(model, c["current"], c["pdn"], c["eff_dist"])
        m    = compute_metrics(pred, c["ir_drop"])
        tc_maes.append(m["mae"])
        tc_f1u.append(m["f1_unet"])
        tc_f1c.append(m["f1_comp"])
        tc_f1p.append(m["f1_pct"])
        print(f"  {c['name']:<14}  {m['mae']*1e3:>8.3f}  "
              f"{m['f1_unet']:>8.4f}  {m['f1_comp']:>8.4f}  {m['f1_pct']:>8.4f}")
        visualise(c["name"] + "_train", c["current"], c["pdn"],
                  c["eff_dist"], c["ir_drop"], pred, train_dir)
    print(f"  {'-'*56}")
    print(f"  {'MEAN':<14}  {np.mean(tc_maes)*1e3:>8.3f}  "
          f"{np.mean(tc_f1u):>8.4f}  {np.mean(tc_f1c):>8.4f}  {np.mean(tc_f1p):>8.4f}")

    print(f"\n{'='*58}")
    print("  Step 3 -- Predicting hidden test cases")
    print(f"{'='*58}")
    hidden_folders = sorted([
        os.path.join(HIDDEN_DIR, d)
        for d in os.listdir(HIDDEN_DIR)
        if os.path.isdir(os.path.join(HIDDEN_DIR, d))
    ])
    print(f"  Found {len(hidden_folders)} hidden cases\n")

    results = {}
    for folder in hidden_folders:
        name = os.path.basename(folder)
        try:
            current, pdn, eff_dist, ir_gt = load_real_testcase(folder)
            pred = predict_map(model, current, pdn, eff_dist)
            m    = compute_metrics(pred, ir_gt)
            results[name] = {"pred": pred, "gt": ir_gt, "metrics": m}
            np.savetxt(os.path.join(OUT_DIR, f"{name}_pred.csv"),
                       pred, delimiter=",", fmt="%.6e")
            visualise(name, current, pdn, eff_dist, ir_gt, pred, OUT_DIR)
        except Exception as exc:
            print(f"  {name}: {exc}")
            import traceback
            traceback.print_exc()

    if results:
        maes = [r["metrics"]["mae"]     for r in results.values()]
        f1u  = [r["metrics"]["f1_unet"] for r in results.values()]
        f1c  = [r["metrics"]["f1_comp"] for r in results.values()]
        f1p  = [r["metrics"]["f1_pct"]  for r in results.values()]
        print(f"\n{'='*65}")
        print(f"  FINAL RESULTS -- XGBoost  ({time.time()-total_t0:.1f}s total)")
        print(f"{'='*65}")
        print(f"  Hidden MAE  (mean): {np.mean(maes)*1e3:.4f} mV")
        print(f"  Hidden F1   (mean): {np.mean(f1u):.4f}  (90th pct threshold)")
        print(f"  Hidden F1_comp    : {np.mean(f1c):.4f}  (0.90 x max threshold)")
        print(f"  Hidden F1_pct     : {np.mean(f1p):.4f}  (reference)")
        print(f"\n  {'Case':<14}  {'MAE(mV)':>8}  {'F1':>8}  {'F1_comp':>8}  {'F1_pct':>8}")
        print(f"  {'-'*56}")
        for n, r in sorted(results.items()):
            print(f"  {n:<14}  {r['metrics']['mae']*1e3:>8.4f}  "
                  f"{r['metrics']['f1_unet']:>8.4f}  "
                  f"{r['metrics']['f1_comp']:>8.4f}  "
                  f"{r['metrics']['f1_pct']:>8.4f}")
        print(f"\n  Model saved: {os.path.abspath(MODEL_PATH)}")
        print(f"  Figures:     {os.path.abspath(OUT_DIR)}/")
        print(f"{'='*65}")

    return model, results
